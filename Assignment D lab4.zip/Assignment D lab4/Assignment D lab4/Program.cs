﻿using System;

namespace Assignment_D_lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            Lab04 YEEEEET = new Lab04();
        }
    }
}
