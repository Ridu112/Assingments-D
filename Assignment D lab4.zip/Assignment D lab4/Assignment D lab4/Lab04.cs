﻿using System;

public class Lab04
{


    public Lab04()
    {
        int a = 1, b = 3, c = 5;
        double x = 2.2, y = 4.4, z = 6.6, answer;
        answer = average(a, b);
        Console.WriteLine("\naverage(a, b) = " + answer);
        answer = average(a, b, c);
        Console.WriteLine("\naverage(a, b, c) = " + answer);
        answer = average(x, y);
        Console.WriteLine("\naverage(x, y) = " + answer);
        answer = average(x, y, z);
        Console.WriteLine("\naverage(x, y, z) = " + answer);
    }
       //calculates averages
    public static double average(double n1, double n2)
    {
        return (n1 + n2) / 2.0;
    }
    public static double average(double n1, double n2, double n3)
    {
        return (n1 + n2 + n3) / 3.0;
    }

    //No bc the double handles int.
    //No it does not calculate the average properly.
    //Yes the double handles it all

}