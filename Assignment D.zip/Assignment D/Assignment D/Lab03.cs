﻿using System;

public class Lab03
{
    public double account = 45.32;
    public double transaction;
    public double ammtIn;
    

    public Lab03()
    {
        Console.WriteLine("Please enter an ammount\nnegative numbers for withdrawls pplease");

        this.ammtIn = Convert.ToDouble(Console.ReadLine());

        if (this.ammtIn > 0)
        {
            this.account += ammtIn;
            Console.WriteLine("New balance: $" + this.account.ToString());
        }
        else if (this.ammtIn < 0)
        {
            this.transaction = this.account + this.ammtIn;
            if (this.transaction < 0)
            {
                Console.WriteLine("\nYou can't take that much out!!");
            }
            else if (this.transaction > 0)
            {
                Console.WriteLine("\nNew balance is: $" + this.transaction);
                Console.WriteLine("\n Here is your $" + Math.Abs(this.ammtIn));
            }
        }
    }

}