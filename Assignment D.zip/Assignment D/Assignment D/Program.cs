﻿
using System;

namespace Assignment_D
{
    class Program
    {
        static void Main(string[] args)
        {
            Lab03 lab = new Lab03();
        }
    }
}
